ALASKA'S TO-DO LIST — FREE WEBSITE

Files:
- index.html — complete responsive website; no paid software required.

How to use:
1. Open index.html to preview it.
2. Upload index.html to any static/free web host.
3. The CALL and TEXT buttons work on phones and use (907) 213-8378.

To change the phone number or services, edit index.html and search for the existing text.
